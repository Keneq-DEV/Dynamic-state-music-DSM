# Especificación completa para el agente — Mod DSM (Dynamic State Music)

## 1. Contexto técnico del proyecto
- **Mod ID:** `dsm` | **Nombre:** Dynamic State Music | **Grupo/Paquete:** `dev.keneq.dsm` | **Versión:** `0.1.0`
- **Entorno:** Minecraft `1.20.1`, Forge `47.2.0`, `official` mappings `1.20.1`, Java `17`, Gradle `8.1.1`.
- **Solo cliente:** `side="CLIENT"` en `mods.toml`. Debe registrar `DisplayTest` (`IGNORESERVERONLY`) y aislar clases cliente con `DistExecutor` para poder entrar a servidores vanilla/sin el mod y no crashear servidores dedicados.
- **Estado del repositorio:** Ya existen `build.gradle`, `gradle.properties`, `mods.toml`, `pack.mcmeta`, `lang/en_us.json`, `lang/es_es.json`, `data/dsm/tags/entity_types/hostiles.json`, `sounds.json`, `default_tracks.toml` y los `.ogg` en `assets/dsm/sounds/`, **pero NO existen los archivos `.java`** (deben diseñarse, probarse y compilarse desde cero).

## 2. Regla crítica sobre los archivos `.ogg` (`0..X` sin límite)
- Las pistas `.ogg` del proyecto siguen numeración desde `0` hasta `X` sin límite fijo (ej.: `danger_0.ogg`, `danger_1.ogg`, ..., `danger_X.ogg`; `hide_0.ogg`, `hide_1.ogg`, ..., `hide_X.ogg`, igual que `step_0, step_1, step_2`).
- **Error previo a evitar:** `sounds.json` y `default_tracks.toml` base tenían entradas como `"hide"` (cuando el archivo real es `hide_0.ogg`) o `"danger_1"` apuntando repetido a `danger_0`.
- **Requisito:**
  - El motor debe soportar comodines (`"dsm:danger_*"`, `"dsm:hide_*"`, etc.) y/o autodescubrimiento desde `ResourceManager` (`assets/dsm/sounds/music/**/*.ogg`) para registrar y reproducir dinámicamente cualquier pista `_0.._X` sin límite, ordenadas naturalmente (`_0, _1, _2... _10`) y validando que el `.ogg` realmente exista en disco antes de reproducirlo.

## 3. Biomas, eliminación de `calm` y música vanilla
- **NO existe música genérica `calm`:** Eliminar `[states.calm]` y `calm_generic` como respaldo.
- Solo suenan los biomas mapeados en `[biome.<namespace>.<path>]` dentro de `config/dsm/tracks.toml` (soporta biomas vanilla y de otros mods).
- **Si el jugador está tranquilo en un bioma NO mapeado en `[biome.*]`, DSM cede el paso y deja sonar las pistas normales de Minecraft.**
- Cuando DSM controla la música (bioma mapeado o cualquier estado activo) silencia la música vanilla (`SoundSource.MUSIC`, con interruptor en config).
- **NUNCA tocar discos (`SoundSource.RECORDS`) ni sonidos de cuevas/ambiente (`SoundSource.AMBIENT`).**

## 4. Comportamiento del motor de audio
1. **Instantáneo y responsivo:** Evaluación tick a tick (`ClientTickEvent`). Estados reactivos (`danger`, `pvp_danger`, `boss`, `jumpscare`, `death`) deben arrancar al instante, sin retardos perceptibles ni fade-ins mudos.
2. **Cero duplicados y cero músicas superpuestas:** Siempre hay un único estado activo y una sola pista principal sonando. Durante el crossfade solo puede haber 1 pista nueva subiendo y máximo 1 saliente bajando a `0.0` hasta detenerse.
3. **No cortar pistas ni repetir siempre la misma:**
   - Las pistas suenan completas (ej. si `danger_1` dura 41s no se corta a la mitad); al terminar rota en bucle (`sequence` o `shuffle` sin repetir hasta agotar lista) respetando `gap_seconds`.
   - Lista de 1 sola canción: bucle infinito (excepto `jumpscare`, que siempre suena 1 sola vez).
   - Al terminar una pelea hace fade-out suave; **al iniciar una nueva pelea en `danger`, recuerda la última pista que sonó y elige una distinta** (no reinicia siempre en `danger_0`).
4. **`danger_*` plano por defecto + interruptor de niveles en config:**
   - **Por defecto (`useThreatLevels = false` en config):** `[states.danger]` es un único pool plano con todos los `danger_*` (`danger_0..danger_X`). Si te ve 1 enemigo suena un `danger_*`; si se suma otro enemigo **NO reinicia ni cambia de lista**.
   - **Configurable (`useThreatLevels = true`):** Permite usar `[states.danger.level_0]`, `level_1`, etc. según número de enemigos si el usuario lo activa en config.
5. **Menús (`menu_pause`, `menu_inventory`) con reanudación exacta:**
   - Al abrir pausa o inventario entra su pista propia y la música de juego previa se pausa/suspende en su canal; **al regresar al juego continúa exactamente donde iba** (sin reiniciar ni duplicarse).
6. **Tolerancia a fallos sin spam:** Si falta música para un estado o falla un `.ogg`, no crashea ni llena el log: queda en silencio y avisa **una sola vez**.

## 5. Qué significa que la detección sea "inteligente" (y bugs que NO deben ocurrir)
1. **Sin falsos positivos en *strip mining* / detrás de muros:**
   - Un mob detrás de piedra sólida en una cueva no te ve ni puede disparar `danger`, `search` ni `hide`.
   - Exigir **línea de visión real** con raycast (`ClipContext.Block.COLLIDER` para que pasto/flores/hojas no rompan falsamente la visión) + señales reales de amenaza/aggro (`Mob.isAggressive()`, `NeutralMob.isAngry()`, `Creeper` hinchándose, `EnderMan` `isCreepy()`, daño reciente o proximidad frontal real).
2. **Sin reinicios de `danger` entre enemigos:**
   - Incluir una pequeña ventana de retención (`dangerHoldSeconds` ~2s) tras perder brevemente línea de visión antes de pasar a `search`, para que un parpadeo de 1–2 ticks al cambiar entre un enemigo y otro no reinicie `danger` desde 0:00.
   - Si la misma lista de `danger` estaba haciendo fade-out y vuelve el peligro enseguida, recuperar esa pista en curso en vez de arrancar otra desde el inicio.
3. **Sin `search` / `hide` infinito:**
   - La pérdida de amenaza se mide estrictamente por tiempo desde el **último contacto visual/daño real**, nunca por "si queda algún mob vivo dentro del radio". Si nadie recupera línea de visión real, la cadena avanza y cierra la sesión limpia.
4. **`escape` inteligente ("corriendo por tu vida"):**
   - Requisitos en PvE: **2+ enemigos** activos + **poca vida** (ratio configurable) + **huida activa** (esprintar, alejarse del centro de amenaza, **hacer pilar de bloques hacia arriba**, **encerrarse** colocando bloques, saltar).
   - Debe tener **ventana de gracia** (unos segundos) para no cortarse si te detienes un momento a poner bloques para pilarear/encerrarte o comer rápido.
   - En `pvp_escape`: mismo criterio desde **1+ jugador** atacante.
5. **`hide` inteligente:**
   - Cuando termina el aggro (tras `dangerHold` + `search` configurable, ej. 5s), entra `hide` (`hide_0..X`).
   - Límite configurable (`hideDurationSeconds`, ej. 12s): si la pista es más corta suena completa y hace fade-out; si es larga (ej. 2 minutos) suena ese máximo y hace fade-out suave hacia el bioma/vanilla (sin cortarse en el tick 0 por esperar inicialización de stream en `SoundManager`).
6. **`group_danger` inteligente:**
   - Histéresis para confirmar grupo sostenido (no cortar `danger` por un mob que pasa medio segundo) y conciencia del tiempo restante de la pista actual: si a la pista de `danger` le quedan pocos segundos para terminar, dejarla cerrar natural antes de entrar a `group_danger`.
7. **Rama PvP (`pvp_danger`, `pvp_group_danger`, `pvp_escape`, `pvp_search`, `pvp_hide`):**
   - Se activa cuando otro jugador te golpea / hay combate PvP (detectable en cliente por `getLastHurtByMob()`, `AttackEntityEvent`, y `hurtTime` junto a jugadores no aliados).
   - `pvp_hide`: al agacharte/ocultarte cerca de otro jugador no aliado (respetando equipos/aliados para no dispararse con amigos) o tras romper visión en PvP.
8. **Prioridad inteligente de estados (de mayor a menor):**
   1. **`death`** (absoluta e inmediata, y punto).
   2. **`menu_pause`** (suspende pista previa y la reanuda al volver).
   3. **`jumpscare`** (reproducción única al sorprenderte un mob de cerca de golpe, con cooldown configurable).
   4. **`boss`** (detectado por barra de jefe en `BossHealthOverlay`). *Nota:* `boss` mantiene el clímax por defecto aunque bajes a medio corazón (`nearDeathOverridesBoss = false` por defecto, configurable).
   5. **`near_death`** (al borde de morir, ~1.5 corazones).
   6. **Rama PvP** (`pvp_escape` > `pvp_group_danger` / `pvp_danger` > `pvp_search` > `pvp_hide`).
   7. **Rama PvE** (`escape` > `group_danger` / `danger` > `search` > `hide`).
   8. **`low_health`** (siempre por debajo de `boss`, `escape` y combate activo para no taparlos).
   9. **`healing`**.
   10. **`menu_inventory`** (suspende pista previa y la reanuda al volver).
   11. **`[biome.*]`** (y si el bioma no está mapeado, música normal de Minecraft).

## 6. Comandos, tags y configuración
- **Tag de entidades:** `data/dsm/tags/entity_types/hostiles.json` (`dsm:hostiles`).
- **Configuración de pistas:** `config/dsm/tracks.toml` (copiado desde `dsm/default_tracks.toml`).
- **Configuración numérica/interruptores:** `config/dsm-client.toml` (radios, tiempos de hold/search/hide/escape/jumpscare, `useThreatLevels`, `muteVanillaMusic`, velocidades de crossfade, umbrales de vida, `nearDeathOverridesBoss`, etc.).
- **Comandos cliente (`/dsm state` y `/dsm reload`):** Deben usar exactamente las claves y cantidad de `%s` ya definidas en `assets/dsm/lang/en_us.json` y `es_es.json`:
  - `dsm.command.state` (5 `%s`)
  - `dsm.command.state.threat` (4 `%s`)
  - `dsm.command.reload.ok` (2 `%s`)
  - `dsm.command.reload.fail` (1 `%s`)
  - `dsm.command.not_tracking` (0 `%s`)